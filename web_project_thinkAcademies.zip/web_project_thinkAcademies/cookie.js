document.addEventListener("DOMContentLoaded", () => {
  const animatedElements = document.querySelectorAll('.slide-up, .fade-in, .pop-in');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1
  });

  animatedElements.forEach(el => {
    el.style.animationPlayState = 'paused';
    observer.observe(el);
  });

  const form = document.getElementById('newsletterForm');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thanks for subscribing to sweet updates! 🍪');
    form.reset();
  });
});
