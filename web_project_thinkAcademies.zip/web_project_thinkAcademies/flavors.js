document.querySelectorAll('.info-btn').forEach(button => {
  button.addEventListener('click', () => {
    alert('More delicious details coming soon! Stay tuned 🍪');
  });
});

function showFlavorInfo(flavorId) {
  const modal = document.getElementById('flavorModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalText = document.getElementById('modalText');

  const flavorData = {
    choco: {
      title: 'Choco Chip Cookie',
      text: 'A classic cookie made with rich brown sugar, butter, vanilla, and large gooey chocolate chunks. Perfect for any time of the day. Texture: chewy center, crispy edges.'
    },
    redvelvet: {
      title: 'Red Velvet Cookie',
      text: 'Decadent red velvet dough with white chocolate chips and a hint of cocoa. Luxurious flavor with cream cheese accents. Great for gifting and special occasions.'
    },
    oatmeal: {
      title: 'Oatmeal Raisin Cookie',
      text: 'Chewy and hearty cookie filled with whole oats, plump raisins, cinnamon spice, and natural sweetness. Great source of fiber and a nostalgic treat.'
    },
    peanut: {
    title: 'Peanut Butter Cookie',
    text: 'A rich and nutty cookie crafted with creamy peanut butter, brown sugar, and a pinch of salt. Soft in the center and slightly crisp at the edges. A dream for peanut lovers!'
  }
  };

  const info = flavorData[flavorId];
  if (info) {
    modalTitle.textContent = info.title;
    modalText.textContent = info.text;
    modal.style.display = 'block';
  }
}

function closeModal() {
  document.getElementById('flavorModal').style.display = 'none';
}

// Close modal when user clicks outside of it
window.onclick = function(event) {
  const modal = document.getElementById('flavorModal');
  if (event.target === modal) {
    modal.style.display = "none";
  }
};
